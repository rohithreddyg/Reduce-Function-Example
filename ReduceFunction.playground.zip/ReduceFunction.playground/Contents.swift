import UIKit

// 1. Implement summation of an Array of Integers

// Regular Implementation
func summation(for numbers:[Int]) -> Int {
  var sum = 0
  numbers.forEach { sum += $0 }
  return sum
}

summation(for: [1, 2, 3, 4])

// Using Reduce Function
let mySum = [1, 2, 3, 4].reduce(0, {$0 + $1})
print(mySum)



// 2. Implement the product of an Array of Integers

// Regular Implementation
func productFunction(for numbers:[Int]) -> Int {
  var product = 1
  numbers.forEach({ product *= $0 })
  return product
}

productFunction(for: [1, 2, 3, 4])

// Using Reduce Function
let myProduct = [1, 2, 3, 4].reduce(1, { $0 * $1 })
print(myProduct)



// 3. Transform an Array of Strings into a sentence

// Regular Implementation
func transformWordsIntoSentence(for words:[String]) -> String {
  var result = ""
  words.forEach({ result += $0 + " "})
  return result
}

let facts = ["I", "am", "the", "greatest", "of", "all", "time"]

transformWordsIntoSentence(for: facts)

// Using Reduce Function
let trueSentence = facts.reduce("", { $0 + $1 + " " })
print(trueSentence)
